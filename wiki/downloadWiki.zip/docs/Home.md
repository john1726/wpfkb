**Project Description**
WPF Touch Screen Keyboard is a re-usable control and toolkit for anyone developing a touch screen application in WPF.

As it stands the project was purpose built to be able to define keyboard layouts in code and only needed one style. I'm currently refactoring the project so that you will be able to define a ControlTemplate and Styles for the keys and try to make life easy for defining different keyboard layouts and interaction.  I'll also be providing some more comprehensive and useful default keyboard controls you can use right out of the box. Keep an eye out for the next version!  In the meantime if the control is styled appropriately for you it has been tested and is production ready.

![WpfKb Test Client](Home_WpfKbTestClient.jpg)

## History
This project was started as part of a proof of concept for a commercial touch screen WPF application that will be commissioned soon. After looking at a few of the other Keyboard offerings available I decided to write and open-source this project as a chance to give back to the community and to learn control development in WPF. I hope it helps someone out there!

## Comments and Contributions
Feel free to comment, log issues/suggestions, or even better contribute to the project!